package com.example.justquiz

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.justquiz.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var currentQuestionIndex = 0
    private var questionsWithOptions: List<Triple<String, List<String>, Map<String, Int>>> = emptyList()
    private val answers: MutableMap<String, String> = mutableMapOf()
    private val selectedOptions: MutableMap<String, String?> = mutableMapOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up the spinner
        val countryOptions = resources.getStringArray(R.array.country_options)
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, countryOptions)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerCountry.adapter = spinnerAdapter

        // Handle spinner item selection
        binding.spinnerCountry.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedCountry = countryOptions[position]
                setQuestionsForCountry(selectedCountry)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        setQuestionsForCountry(countryOptions[0]) // Set the initial set of questions

        binding.left.setOnClickListener {
            currentQuestionIndex--
            if (currentQuestionIndex < 0) {
                currentQuestionIndex = 0
            }
            setQuestionAndOptions(currentQuestionIndex)
        }

        binding.right.setOnClickListener {
            currentQuestionIndex++
            if (currentQuestionIndex == questionsWithOptions.size) {
                currentQuestionIndex--
            }
            setQuestionAndOptions(currentQuestionIndex)
        }

        // Set onClickListener for each RadioButton to update the selected option
        binding.optionA.setOnClickListener { updateSelectedOption(it as RadioButton) }
        binding.optionB.setOnClickListener { updateSelectedOption(it as RadioButton) }
        binding.optionC.setOnClickListener { updateSelectedOption(it as RadioButton) }
        binding.optionD.setOnClickListener { updateSelectedOption(it as RadioButton) }

        // Set onClickListener for the Submit button
        binding.submitButton.setOnClickListener {
            if (currentQuestionIndex < questionsWithOptions.size - 1) {
                // If not on the last question, proceed to the next question
                currentQuestionIndex++
                setQuestionAndOptions(currentQuestionIndex)
            } else {
                // If on the last question, navigate to the submit page
                val selectedCountry = countryOptions[binding.spinnerCountry.selectedItemPosition]
                navigateToSubmitPage(selectedCountry)
            }
        }
    }

    private fun setQuestionsForCountry(country: String) {
        // Update the list of questionsWithOptions based on the selected country
        questionsWithOptions = when (country) {
            "Ghana" -> listOf(
                Triple(
                    "Q1. HOW MANY MEMBERS ARE THERE IN THE HOUSEHOLD?",
                    listOf("1-5", "5-10", "10-15", "15-20"),
                    mapOf(
                        "1-5" to 1, // Assigning marks to each option
                        "5-10" to 2,
                        "10-15" to 3,
                        "15-20" to 4
                    )
                ),
                Triple(
                    "Q2. IN THE PAST MONTH, HAVE YOU PURCHASED ANY CHICKEN EGGS (FRESH OR SINGLE)?",
                    listOf("Yes", "No", "I don't consume eggs", "Prefer not to answer"),
                    mapOf(
                        "Yes" to 5, // Assigning marks to each option
                        "No" to 6,
                        "I don't consume eggs" to 7,
                        "Prefer not to answer" to 8
                    )
                ),
                Triple(
                    "Q3. IN THE PAST MONTH, HAVE YOU PURCHASED ANY RAW OR CORNED BEEF?",
                    listOf("Yes", "No", "I don't consume raw or corned beef", "Prefer not to answer"),
                    mapOf(
                        "Yes" to 9, // Assigning marks to each option
                        "No" to 10,
                        "I don't consume raw or corned beef" to 11,
                        "Prefer not to answer" to 12
                    )
                ),
                Triple(
                    "Q4. WHAT IS THE MAIN CONSTRUCTION MATERIAL USED FOR THE OUTER WALL?",
                    listOf("Stones", "Earth-based bricks", "Sand-cement", "Other"),
                    mapOf(
                        "Stones" to 13, // Assigning marks to each option
                        "Earth-based bricks" to 14,
                        "Sand-cement" to 15,
                        "Other" to 16
                    )
                ),
                Triple(
                    "Q5. WHAT IS THE MAIN FUEL USED BY THE HOUSEHOLD FOR COOKING?",
                    listOf("Wood", "Charcoal", "Crop residue", "Gas"),
                    mapOf(
                        "Wood" to 17, // Assigning marks to each option
                        "Charcoal" to 18,
                        "Crop residue" to 19,
                        "Gas" to 20
                    )
                ),
                // Add more questions for GHANA
            )
            "Malawi" -> listOf(
                Triple(
                    "Q1. HOW MANY MEMBERS ARE THERE IN THE HOUSEHOLD?",
                    listOf("1-5", "5-10", "10-15", "15-20"),
                    mapOf(
                        "1-5" to 1, // Assigning marks to each option
                        "5-10" to 2,
                        "10-15" to 3,
                        "15-20" to 4
                    )
                ),
                Triple(
                    "Q2. IS THE HOUSEHOLD HEAD ABLE TO READ AND WRITE IN ENGLISH?",
                    listOf("Yes", "No", "Partially", "Prefer not to say"),
                    mapOf(
                        "Yes" to 13, // Assigning marks to each option
                        "No" to 14,
                        "Partially" to 15,
                        "Prefer not to say" to 16
                    )
                ),
                Triple(
                    "Q3. THE ROOF OF THE MAIN DWELLING IS PREDOMINANTLY MADE OF WHAT MATERIAL?",
                    listOf("Stones", "Earth-based bricks", "Sand-cement", "Other"),
                    mapOf(
                        "Stones" to 13, // Assigning marks to each option
                        "Earth-based bricks" to 14,
                        "Sand-cement" to 15,
                        "Other" to 16
                    )
                ),
                Triple(
                    "Q4. THE FLOOR OF THE MAIN DWELLING IS PREDOMINANTLY MADE OF WHAT MATERIAL?",
                    listOf("Stones", "Earth-based bricks", "Sand-cement", "Other"),
                    mapOf(
                        "Stones" to 13, // Assigning marks to each option
                        "Earth-based bricks" to 14,
                        "Sand-cement" to 15,
                        "Other" to 16
                    )
                ),
                Triple(
                    "Q5. WHAT IS THE MAIN FUEL USED BY THE HOUSEHOLD FOR COOKING?",
                    listOf("Wood", "Charcoal", "Crop residue", "Gas"),
                    mapOf(
                        "Wood" to 17, // Assigning marks to each option
                        "Charcoal" to 18,
                        "Crop residue" to 19,
                        "Gas" to 20
                    )
                ),
                Triple(
                    "Q6. OVER THE PAST ONE WEEK (7 DAYS), DID YOU OR OTHERS IN YOUR HOUSEHOLD CONSUME ANY SUGAR?",
                    listOf("Yes", "No", "I dont remember", "Prefer not to answer"),
                    mapOf(
                        "Yes" to 17, // Assigning marks to each option
                        "No" to 18,
                        "I dont remember" to 19,
                        "Prefer not to answer" to 20
                    )
                ),
                // Add more questions for Malawi
            )
            "Burkina Faso" -> listOf(
                Triple(
                    "Q1. HOW MANY MEMBERS ARE THERE IN THE HOUSEHOLD?",
                    listOf("1-5", "5-10", "10-15", "15-20"),
                    mapOf(
                        "1-5" to 1, // Assigning marks to each option
                        "5-10" to 2,
                        "10-15" to 3,
                        "15-20" to 4
                    )
                ),
                Triple(
                    "Q2. DOES THE MALE HOUSEHOLD HEAD OR SPOUSE READ AND WRITE IN ANY LANGUAGE?",
                    listOf("Yes", "No", "Partially", "Prefer not to say"),
                    mapOf(
                        "Yes" to 13, // Assigning marks to each option
                        "No" to 14,
                        "Partially" to 15,
                        "Prefer not to say" to 16
                    )
                ),
                Triple(
                    "Q3. DID EVERY CHILD AGED 7 TO 14 ATTEND FORMAL SCHOOL DURING THE LAST SCHOOL YEAR?",
                    listOf("Yes", "No", "Some did, some did not", "Prefer not to answer"),
                    mapOf(
                        "Yes" to 13, // Assigning marks to each option
                        "No" to 14,
                        "Some did, some did not" to 15,
                        "Prefer not to answer" to 16
                    )
                ),
                Triple(
                    "Q4. WHAT IS THE MATERIAL USED TO CONSTRUCT THE FLOOR?",
                    listOf("Stones", "Earth-based bricks", "Sand-cement", "Other"),
                    mapOf(
                        "Stones" to 13, // Assigning marks to each option
                        "Earth-based bricks" to 14,
                        "Sand-cement" to 15,
                        "Other" to 16
                    )
                ),
                Triple(
                    "Q5. HAS YOUR HOUSEHOLD CONSUMED MILK AND/OR DAIRY PRODUCTS IN THE LAST DAYS?",
                    listOf("Yes", "No", "Occasionally", "Prefer not to answer"),
                    mapOf(
                        "Yes" to 13, // Assigning marks to each option
                        "No" to 14,
                        "Occasionally" to 15,
                        "Prefer not to answer" to 16
                    )
                ),
                Triple(
                    "Q6. HAS YOUR HOUSEHOLD CONSUMED SUGAR (GRANULATED OR IN THE FORM OF CUBES) IN THE LAST 7 DAYS?",
                    listOf("Yes", "No", "I dont remember", "Prefer not to answer"),
                    mapOf(
                        "Yes" to 13, // Assigning marks to each option
                        "No" to 14,
                        "I dont remember" to 15,
                        "Prefer not to answer" to 16
                    )
                ),
                Triple(
                    "Q7. WHAT IS THE MAIN SOURCE OF HOUSEHOLD LIGHTING?",
                    listOf("Firewood", "Charcoal", "Kerosene", "Animal dung"),
                    mapOf(
                        "Firewood" to 13, // Assigning marks to each option
                        "Charcoal" to 14,
                        "Kerosene" to 15,
                        "Animal dung" to 16
                    )
                ),
                // Add more questions for Burkina Faso
            )
            else -> emptyList()
        }

        // Reset the currentQuestionIndex and update the questions
        currentQuestionIndex = 0
        setQuestionAndOptions(currentQuestionIndex)
    }

    private fun setQuestionAndOptions(index: Int) {
        val (question, options, optionMarks) = questionsWithOptions[index]
        binding.tvQuestion.text = question
        binding.optionA.text = "${options[0]} (${optionMarks[options[0]]} marks)"
        binding.optionB.text = "${options[1]} (${optionMarks[options[1]]} marks)"
        binding.optionC.text = "${options[2]} (${optionMarks[options[2]]} marks)"
        binding.optionD.text = "${options[3]} (${optionMarks[options[3]]} marks)"


        // Check if a selection was made for this question
        if (selectedOptions.containsKey(question)) {
            // If a selection was made, find the corresponding RadioButton and set it as checked
            val selectedOption = selectedOptions[question]
            when (selectedOption) {
                options[0] -> binding.optionA.isChecked = true
                options[1] -> binding.optionB.isChecked = true
                options[2] -> binding.optionC.isChecked = true
                options[3] -> binding.optionD.isChecked = true
            }
        } else {
            // If no selection was made, clear the checked state of the RadioGroup
            binding.optionsRadioGroup.clearCheck()
        }
    }

    private fun updateSelectedOption(radioButton: RadioButton) {
        val question = questionsWithOptions[currentQuestionIndex].first
        selectedOptions[question] = radioButton.text.toString()
        val selectedMarks = questionsWithOptions[currentQuestionIndex].third[radioButton.text.toString()]
        Log.d("SelectedOption", "Question ${currentQuestionIndex + 1}: ${selectedOptions[question]} ($selectedMarks marks)")

        // Add the selected answer to the dictionary
        answers["Question ${currentQuestionIndex + 1}"] = selectedOptions[question] ?: "Not answered"
    }

    private fun navigateToSubmitPage(selectedCountry: String) {
        // Inflate the submit page layout and display it
        val submitLayout = layoutInflater.inflate(R.layout.activity_submit, null)
        val tvSelectedCountry = submitLayout.findViewById<TextView>(R.id.tvSelectedCountry)
        val tvAnswers = submitLayout.findViewById<TextView>(R.id.tvAnswers)
        val btnSubmit = submitLayout.findViewById<TextView>(R.id.btnSubmit)

        // Set the selected country name
        tvSelectedCountry.text = "Selected Country: $selectedCountry"
        Log.d("FinalAnswers", "Selected Country: $selectedCountry")

        // Build the answers text to display and print in the log
        val allAnswers = StringBuilder()
        for ((question, answer) in answers) {
            val formattedAnswer = answer ?: "No answer"
            allAnswers.append("$question: $formattedAnswer\n")

            Log.d("FinalAnswers", "$question: $formattedAnswer")
        }
        tvAnswers.text = allAnswers.toString()

        // Create a Dialog to show the submit page
        val dialog = AlertDialog.Builder(this)
            .setView(submitLayout)
            .setCancelable(false)
            .create()

        // Handle the submit button click
        btnSubmit.setOnClickListener {
            // Clear the answers dictionary, selectedOptions map, and return to the first question
            answers.clear()
            selectedOptions.clear()
            currentQuestionIndex = 0
            setQuestionAndOptions(currentQuestionIndex)
            dialog.dismiss()
        }

        // Show the Dialog
        dialog.show()
    }
}