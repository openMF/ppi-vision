package com.example.myapplication
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.example.myapplication.R
import com.example.myapplication.ml.Yolov5nFp16
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.common.FileUtil
import org.tensorflow.lite.support.common.FileUtil.loadLabels
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.model.Model
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.io.BufferedReader
import java.nio.ByteBuffer
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStreamReader

lateinit var yolo: Yolov5nFp16
val numClasses = 80
var startIndex = 0


class MainActivity : AppCompatActivity() {
    lateinit var labels:List<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        labels = loadLabels(this, "labels.txt")




        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the YOLOv5 model.
        val context = this
        yolo = Yolov5nFp16.newInstance(context)

        // Load your input image.
        val inputBitmap = BitmapFactory.decodeStream(assets.open("bus.jpeg"))

        // Resize the input image to the expected size (640x640).
        val resizedBitmap = Bitmap.createScaledBitmap(inputBitmap, 640, 640, true)

        // Convert the resized image to a ByteBuffer.
        val byteBuffer = convertBitmapToByteBuffer(resizedBitmap)

        // Create inputs for inference.
        val inputFeature0 = TensorBuffer.createFixedSize(intArrayOf(1, 640, 640, 3), DataType.FLOAT32)
        inputFeature0.loadBuffer(byteBuffer)

        // Run model inference and get the result.
        val outputs = yolo.process(inputFeature0)
        val outputFeature0 = outputs.outputFeature0AsTensorBuffer
        var output_array=outputFeature0.intArray
        // Iterate over class predictions.
        val classPredictions = FloatArray(numClasses)
        for (c in 0 until numClasses) {
            classPredictions[c] = outputFeature0.getFloatValue(startIndex + 5 + c)
        }

// Find the class with the highest confidence.
        val maxConfidenceIndex = classPredictions.indices.maxByOrNull { classPredictions[it] } ?: -1

// Get the corresponding class label.
        val maxConfidenceClassLabel = if (maxConfidenceIndex != -1) labels[maxConfidenceIndex] else "Unknown"

// You can now print or process the bounding box, class predictions, and the class label.
//        println("CenterX: $centerX, CenterY: $centerY, Width: $width, Height: $height, Confidence: $confidence")
        Log.d("output_array","${arrayListOf(output_array)}")
        println("Predicted Class: $maxConfidenceClassLabel")


        // Process the output if needed, e.g., post-processing for object detection.

        // Release model resources if no longer used.
        yolo.close()
    }

    private fun convertBitmapToByteBuffer(bitmap: Bitmap): ByteBuffer {
        val byteBuffer = ByteBuffer.allocateDirect(4 * bitmap.width * bitmap.height * 3)
        bitmap.copyPixelsToBuffer(byteBuffer)
        return byteBuffer
    }
    private fun loadLabels(labelFilePath: String): List<String> {
        try {
            val labelInputStream = assets.open(labelFilePath)
            val labelReader = BufferedReader(InputStreamReader(labelInputStream))
            val labels = ArrayList<String>()
            var line: String?
            while (labelReader.readLine().also { line = it } != null) {
                labels.add(line!!)
            }
            labelReader.close()
            return labels
        } catch (e: IOException) {
            // Handle the exception
            e.printStackTrace()
        }
        return emptyList()
    }

}
